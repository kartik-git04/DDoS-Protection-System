Python wrapper for tshark, allowing python packet parsing using wireshark dissectors.

See https://github.com/KimiNewt/pyshark/ for documentation.
